#include <stdio.h>
#include "linkedList.h"
int main(){
   time_t t;
   /* Intializes random number generator */
   srand((unsigned) time(&t));
  //Create element object
  ELEMENT_t element;
  //Test Integer type
  element.i = -15; 
  GENERIC_LIST_ITEM_t myItem = {INT_TYPE,element,NULL};
  printItem(&myItem);
  //Test Character type
  myItem.element.c = 'A';
  myItem.type=CHAR_TYPE;
  printItem(&myItem);
  //Test double type
  myItem.element.d = 1.54;
  myItem.type=DOUBLE_TYPE;
  printItem(&myItem);
  //Test string type
  char* myString = "Hello World!";
  myItem.element.s = myString;
  myItem.type=STRING_TYPE;
  printItem(&myItem);
  
  //Create list object & intialize
  GENERIC_LIST_t myList;
  myList.head = NULL;
  myList.size = 0;
  //Add integer item
  element.i = 5;
  addElement(&myList,INT_TYPE,element);
  //Add character item
  element.c = 'A';
  addElement(&myList,CHAR_TYPE,element);
  //Add double item
  element.d = 3.4;
  addElement(&myList,DOUBLE_TYPE,element);
  //Print the list
  printList(&myList);
  //Remove middle item
  removeElement(&myList,1);
  printList(&myList);
  //Remove end item
  removeElement(&myList,1);
  printList(&myList);
  //Remove beginning item
  removeElement(&myList,0);
  printList(&myList);

  //Add 0-15 integers sequentially
  int i = 0;
  for(i=0;i<15;i++){
    element.i = i;
    addElement(&myList,INT_TYPE,element);
  }
  //Print the list
  printList(&myList);
  //Remove elements at random
  for(i=15;i>0;i--){
    removeElement(&myList,rand()%i);
    //Print list every 10
    if(i%10==0){
      printList(&myList);
    }
  }
  return 0;
}
