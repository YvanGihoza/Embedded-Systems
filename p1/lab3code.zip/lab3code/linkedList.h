#include <stdlib.h>
#include <stdio.h>

//Union holds only one of these element types
typedef union element{
  char c;
  signed long int i;
  double d;
  char* s;
} ELEMENT_t;

//Use this enum type to specify which element type is being used
typedef enum element_type{CHAR_TYPE=0,INT_TYPE,DOUBLE_TYPE,STRING_TYPE}
 ELEMENT_TYPE_e;

//Item in a list; holds element, element type, and the address of the next item
typedef struct generic_list_item{
  ELEMENT_TYPE_e type;
  ELEMENT_t element;
  //Must use struct notation here because typedef hasn't finished
  struct generic_list_item *next;
} GENERIC_LIST_ITEM_t;

//List structure; Has pointer to first item and a size
typedef struct generic_list{
  GENERIC_LIST_ITEM_t *head;
  int size;
} GENERIC_LIST_t;

void printItem(const GENERIC_LIST_ITEM_t *item);
void addElement(GENERIC_LIST_t *list, ELEMENT_TYPE_e type, ELEMENT_t element);
void removeElement(GENERIC_LIST_t *list,int index);
void printList(const GENERIC_LIST_t *list);

